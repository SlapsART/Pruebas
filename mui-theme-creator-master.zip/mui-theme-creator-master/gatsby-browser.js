import wrapWithProvider from "./wrap-with-provider"
export const wrapRootElement = wrapWithProvider
