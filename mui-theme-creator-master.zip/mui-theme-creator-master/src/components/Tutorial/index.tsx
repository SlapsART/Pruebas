export { default } from "./Tutorial"
