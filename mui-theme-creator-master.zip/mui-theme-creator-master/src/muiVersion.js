// Auto-generated on build by extractMuiVersion.sh
export default "^5.6.0"
